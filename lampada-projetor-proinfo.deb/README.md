# Lampada-Projetor-Proinfo
Software para ligar e desligar o Projetor Proinfo Automaticamente
